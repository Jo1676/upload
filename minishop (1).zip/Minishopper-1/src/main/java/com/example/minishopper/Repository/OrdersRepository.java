package com.example.minishopper.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.minishopper.model.Orders;
import java.util.List;
public interface OrdersRepository extends JpaRepository<Orders, Long> {
   List<Orders> findByCustomerId(Long customerId);
}