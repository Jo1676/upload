package com.example.minishopper.model;


import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "orders")
@JsonIgnoreProperties(ignoreUnknown = true) // Add this annotation
public class Orders {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;
   private Date orderDate;
   private String orderStatus;
   @ManyToMany(cascade = CascadeType.ALL)
   private List<Items> itemList;
   @ManyToOne
   private Customer customer;
   // Getters and Setters
   public Long getOrderId() {
       return id;
   }
   public void setOrderId(Long orderId) {
this.id = orderId;
   }
   public Customer getCustomer() {
       return customer;
   }
   public void setCustomer(Customer customer) {
       this.customer = customer;
   }
   public List<Items> getItemList() {
       return itemList;
   }
   public void setItemList(List<Items> itemList) {
       this.itemList = itemList;
   }
   public Date getOrderDate() {
       return orderDate;
   }
   public void setOrderDate(Date orderDate) {
       this.orderDate = orderDate;
   }
   public String getOrderStatus() {
       return orderStatus;
   }
   public void setOrderStatus(String orderStatus) {
       this.orderStatus = orderStatus;
   }
}
