package com.example.minishopper.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.example.minishopper.DTO.CustomerRegistrationResponse;
import com.example.minishopper.DTO.LoginRequest;
import com.example.minishopper.DTO.MessageResponse;
import com.example.minishopper.Repository.CustomerRepository;
import com.example.minishopper.Service.CustomerService;
import com.example.minishopper.model.Customer;
import com.example.minishopper.security.jwt.JwtUtils;
import com.example.minishopper.security.service.UserDetailsImpl;
import com.example.minishopper.utils.MiniShopperUtils;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Valid;
import jakarta.validation.Validator;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private CustomerRepository customerRepository;
    
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    JwtUtils jwtUtils;
    
    private final Validator validator;
    
    public CustomerController(Validator validator) {
    	this.validator=validator;
    }
    
    @PostMapping("/register")
    public ResponseEntity<?> registerCustomer(@Valid @RequestBody Customer customer,BindingResult bindingResult) {
    	String response = "User Creation Failed";
    	Set<ConstraintViolation<Customer>> violations = validator.validate(customer);
   
    	if (!violations.isEmpty()) {
    	List<String> errors = new ArrayList<>();
    	for (ConstraintViolation<Customer> violation : violations) {
    	errors.add(violation.getMessage());
    	}
    	Map<String, Object> data = new HashMap<>();
    	data.put("message", errors);
    	data.put("success", false);
    	return ResponseEntity.status(HttpStatus.BAD_REQUEST)
    	.body(new MessageResponse(HttpStatus.BAD_REQUEST.value(), data));
    	}
    	try {
	        Customer registeredCustomer = customerService.registerCustomer(customer);
	        if(Objects.nonNull(registeredCustomer)) {
	        	response = "Registration Successful";
	        	return new ResponseEntity<>(response, HttpStatus.CREATED);
	        }
    	}
    	catch(Exception e) {
    		System.out.println("Exception occurred, exception: "+e);
    	}
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    	
		
    }
    @PostMapping("/login")
    public ResponseEntity<?> loginCustomer(@RequestBody LoginRequest loginRequest) {
        boolean isAuthenticated = customerService.authenticate(loginRequest.getEmail(), loginRequest.getPassword());
        if (isAuthenticated) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        }
    }
    
    @GetMapping("/test")
    public String test() {
    	return "hello";
    }
    
    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
    try {
    Authentication authentication = authenticationManager.authenticate(
    new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
    SecurityContextHolder.getContext().setAuthentication(authentication);
    UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
    ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userDetails);
    List<String> roles = userDetails.getAuthorities().stream().map(item -> item.getAuthority())
    .collect(Collectors.toList());
   Customer user = customerRepository.findByEmail(loginRequest.getEmail());
    Map<String, Object> data = new HashMap<>();
    data.put("token", jwtCookie.getValue());
    data.put("user", user);
    data.put("message", "You've been signed In successfully!");
    data.put("sucess", true);
    return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
    .body(new MessageResponse(HttpStatus.OK.value(), data));
    } catch (Exception e) {
    	System.out.println("Error "+e);
    Map<String, Object> data = new HashMap<>();
    data.put("message", "Please Enter Correct UserName and Password!");
    data.put("success", false);
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
    .body(new MessageResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), data));
    }
    }

    @GetMapping("/orders")
    public void getAllOrdersForACustomer(@RequestParam Long userId) {
    	return;
    }
}