package com.example.minishopper.Service;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.minishopper.DTO.AddItemRequest;
import com.example.minishopper.DTO.GetAllItemsRequest;
import com.example.minishopper.Repository.CustomerRepository;
import com.example.minishopper.Repository.ItemRepository;
import com.example.minishopper.model.Customer;
import com.example.minishopper.model.Items;
 

 
@Service

public class ItemService {

@Autowired
private ItemRepository itemRepository;

@Autowired
private CustomerRepository customerRespository;

public Items addItems (AddItemRequest item) throws Exception {
	Customer customer = customerRespository.findByEmail(item.getMailId());
	if(Objects.isNull(customer)) {
		return null;
	}
	Items itemToBeSaved = new Items();
	itemToBeSaved.setItemId(item.getId());
	itemToBeSaved.setItemName(item.getItemName());
	itemToBeSaved.setPrice(item.getPrice());
	
	itemToBeSaved.setQuantity(item.getQuantity());

	return itemRepository.save(itemToBeSaved);
	
}
public List<Items> getAllItems(GetAllItemsRequest getAllItemsRequest) throws Exception {
	Customer customer = customerRespository.findByEmail(getAllItemsRequest.getMailId());
	if(Objects.isNull(customer)) {
		return null;
	}
	List<Items> items = itemRepository.findAll();
	return items;
}

}
