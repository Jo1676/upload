package com.example.minishopper.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.minishopper.DTO.AddressRequest;
import com.example.minishopper.Repository.AddressRepository;
import com.example.minishopper.model.Address;
 
 
@Service
public class AddressService {
    @Autowired
    private AddressRepository addressRepository;
    public void processAddress(AddressRequest request) {
        // Process the purchase order request and save it to the database
        Address address = new Address();
        address.setDoorNumber(request.getDoorNumber()); 
        address.setStreet(request.getStreet());
        address.setLandmark(request.getLandmark());
        address.setPincode(request.getPincode());

        addressRepository.save(address);
    }
}
