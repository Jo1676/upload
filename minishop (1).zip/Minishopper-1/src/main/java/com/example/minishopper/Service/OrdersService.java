package com.example.minishopper.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.minishopper.Repository.OrdersRepository;
import com.example.minishopper.model.Orders;

import java.util.List;
@Service
public class OrdersService {
   @Autowired
   private OrdersRepository ordersRepository;
   public Orders placeOrder(Orders order) {
       order.setOrderStatus("Pending"); // Initially setting the status to Pending
       return ordersRepository.save(order);
   }
   public List<Orders> getUserOrders(Long customerId) {
       return ordersRepository.findByCustomerId(customerId);
   }
   public List<Orders> getAllOrders() {
       return ordersRepository.findAll();
   }
   public Orders updateOrder(Orders order) {
       Orders existingOrder = ordersRepository.findById(order.getOrderId()).orElseThrow(() -> new RuntimeException("Order not found"));
       if ("Pending".equals(existingOrder.getOrderStatus())) {
           existingOrder.setItemList(order.getItemList());
           return ordersRepository.save(existingOrder);
       } else {
           throw new RuntimeException("Only pending orders can be updated");
       }
   }
   public Orders fulfillOrder(Long orderId) {
       Orders order = ordersRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
       if (order.getItemList().stream().allMatch(item -> item.getQuantity() > 0)) {
           order.setOrderStatus("Fulfilled");
           // Generate receipt logic can be added here
           return ordersRepository.save(order);
       } else {
           throw new RuntimeException("Some items are out of stock");
       }
   }
   public Orders rejectOrder(Long orderId) {
       Orders order = ordersRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
       order.setOrderStatus("Rejected");
       return ordersRepository.save(order);
   }
}