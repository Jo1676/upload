package com.example.minishopper.Service;

 
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.minishopper.Repository.CustomerRepository;
import com.example.minishopper.model.Customer;
 

 
@Service

public class CustomerService {
	@Autowired
	private PasswordEncoder passwordEncoder;
	

@Autowired

private CustomerRepository customerRepository;
 
public Customer registerCustomer(Customer customer) throws Exception{
	List<String> roles=new ArrayList<String>();
	roles.add("ROLE_ADMIN");
 customer.setPassword(passwordEncoder.encode(customer.getPassword()));
 customer.setRoles(roles);
     return customerRepository.save(customer);

}
 
public boolean authenticate(String email, String password) {

     Customer customer = customerRepository.findByEmail(email);

     return customer != null && customer.getPassword().equals(password);

}

public void getAllOrdersForACustomer(Long userId) {
	
}

}

 

