package com.example.minishopper.DTO;

import java.util.List;

public class GetAllItemsRequest {

	private String mailId;
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
}
