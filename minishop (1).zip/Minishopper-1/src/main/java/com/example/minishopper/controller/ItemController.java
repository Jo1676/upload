package com.example.minishopper.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.minishopper.DTO.AddItemRequest;
import com.example.minishopper.DTO.GetAllItemsRequest;
import com.example.minishopper.DTO.MessageResponse;
import com.example.minishopper.Service.ItemService;
import com.example.minishopper.model.Items;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/items")
public class ItemController {
    @Autowired
    private ItemService itemService;
    @PostMapping("/add")
    public ResponseEntity<Object> addItem(@Valid @RequestBody AddItemRequest item) {
    	try {
    		
    		if(item.getQuantity()==0) {
    	   	Map<String, Object> data = new HashMap<>();
        	data.put("message", "Please add atleast one item");
        	data.put("success", false);
        	return ResponseEntity.status(HttpStatus.BAD_REQUEST)
        	.body(new MessageResponse(HttpStatus.BAD_REQUEST.value(), data));
    		}else if(item.getQuantity()>50) {
        	   	Map<String, Object> data = new HashMap<>();
            	data.put("message", "Maximum item you can add is 50 only");
            	data.put("success", false);
            	return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            	.body(new MessageResponse(HttpStatus.BAD_REQUEST.value(), data));
    		}
    		Items addedItem = itemService.addItems(item);
    		if(Objects.isNull(addedItem)) {
    			System.out.println("User Invalid, hence returning");
    			return new ResponseEntity<>("Invalid user", HttpStatus.UNAUTHORIZED);
    		}
    		return new ResponseEntity<>("Item added successfully", HttpStatus.OK);
    	}
    	catch(Exception e) {
    		System.out.println("Exception caught" + e);
    	}
    	return new ResponseEntity<>("Add Items Request Failure",HttpStatus.INTERNAL_SERVER_ERROR);
        
    }
    @GetMapping("/getAll")
    public ResponseEntity<Object> getAllItems(@RequestBody GetAllItemsRequest allItemsRequest) {
    	try {
    		List<Items> items=itemService.getAllItems(allItemsRequest);
    		if(Objects.isNull(items)) {
    			System.out.println("User Invalid, hence returning");
    			return new ResponseEntity<>("Invalid user", HttpStatus.UNAUTHORIZED);
    		}
    		return new ResponseEntity<>(items, HttpStatus.OK);
    	}
    	catch(Exception e) {
    		System.out.println("Exception caught" + e);
    	}
    	return new ResponseEntity<>("Get All Items Request Failure",HttpStatus.INTERNAL_SERVER_ERROR);
    }
}