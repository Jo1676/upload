package com.example.minishopper.DTO;

import java.util.List;

public class OrderRequest {

	private Long userId;
	private String mailId;
	private List<Long> itemIdList;
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public List<Long> getItemIdList() {
		return itemIdList;
	}
	public void setItemIdList(List<Long> itemIdList) {
		this.itemIdList = itemIdList;
	}
	
}
