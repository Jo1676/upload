package com.example.minishopper.model;


import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

import jakarta.validation.constraints.NotBlank;

import jakarta.validation.constraints.NotNull;

import jakarta.validation.constraints.Pattern;

import jakarta.validation.constraints.Positive;

@Entity

@Table(name = "item_quantities")

public class ItemQuantity {

    @Id

    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;

    @NotBlank(message = "Item name is required")

    @Pattern(regexp = "^[a-zA-Z0-9 ]+$", message = "Item name should not contain special characters")

    private String itemName;

    @NotNull(message = "Quantity is required")

    @Positive(message = "Quantity must be a positive number")

    private int quantity;

    @ManyToOne(fetch = FetchType.EAGER)

    @JoinColumn(name = "order_id", nullable = false)

    @JsonBackReference

    private Orders order;

    // Getters and Setters

    public Long getId() {

        return id;

    }

    public void setId(Long id) {
this.id = id;

    }

    public String getItemName() {

        return itemName;

    }

    public void setItemName(String itemName) {

        this.itemName = itemName;

    }

    public int getQuantity() {

        return quantity;

    }

    public void setQuantity(int quantity) {

        this.quantity = quantity;

    }

    public Orders getOrder() {

        return order;

    }

    public void setOrder(Orders order) {

        this.order = order;

    }

}