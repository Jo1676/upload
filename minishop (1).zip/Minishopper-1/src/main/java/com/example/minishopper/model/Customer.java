	package com.example.minishopper.model;
	
	import java.util.List;
	
	import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
	import jakarta.persistence.Column;
	import jakarta.persistence.Entity;
	import jakarta.persistence.GeneratedValue;
	import jakarta.persistence.GenerationType;
	import jakarta.persistence.Id;
	import jakarta.persistence.OneToMany;
	import jakarta.persistence.Table;
	import jakarta.validation.constraints.Email;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.Pattern;
	
	@Entity
	
	@Table(name = "customer_list")
	
	
	public class Customer {
	
		@Id
	
		@GeneratedValue(strategy = GenerationType.IDENTITY)
	
		private Long id;
	
		@NotBlank(message = "Name is required")
		   @Pattern(regexp = "^[a-zA-Z0-9 ]+$", message = "Name should not contain special characters")
	
		private String firstName;
	
		@NotBlank
	
		private String lastName;
	
		@NotBlank
	
		@Email
		@Column(unique=true)
	
		private String email;
	
		@NotBlank
	
		private String password;
		
		@NotBlank
		@Pattern(regexp = ".*\\d{6}.*", message = "Address must contain a valid PIN code")
		private String address;
		
		private List<String> roles;
		
		@JsonIgnore
		@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
		@JsonManagedReference
		private List<Orders> orderList;
	
		public List<Orders> getOrderList() {
			return orderList;
		}
	
		public void setOrderList(List<Orders> orderList) {
			this.orderList = orderList;
		}
	
		public Long getId() {
	
			return id;
	
		}
	
		public void setId(Long id) {
	
			this.id = id;
	
		}
	
		public String getFirstName() {
	
			return firstName;
	
		}
	
		public void setFirstName(String firstName) {
	
			this.firstName = firstName;
	
		}
	
		public String getLastName() {
	
			return lastName;
	
		}
	
		public void setLastName(String lastName) {
	
			this.lastName = lastName;
	
		}
	
		public String getEmail() {
	
			return email;
	
		}
	
		public void setEmail(String email) {
	
			this.email = email;
	
		}
	
		public String getPassword() {
	
			return password;
	
		}
	
		public void setPassword(String password) {
	
			this.password = password;
	
		}
	
		public String getAddress() {
			return address;
		}
	
		public void setAddress(String address) {
			this.address = address;
		}
	
		public List<String> getRoles() {
			return roles;
		}
	
		public void setRoles(List<String> roles) {
			this.roles = roles;
		}
	
		@Override
		public String toString() {
			return "Customer [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
					+ ", password=" + password + ", address=" + address + ", roles=" + roles + ", orderList=" + orderList
					+ "]";
		}
	
	
		
	
	}