package com.example.minishopper.DTO;

import java.util.List;

import com.example.minishopper.model.Customer;

public class CustomerOrders {

	private Customer customer;
	
	private List<OrderDto> orderList;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<OrderDto> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<OrderDto> orderList) {
		this.orderList = orderList;
	}
	
}
