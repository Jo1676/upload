package com.example.minishopper.model;

import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;

import jakarta.persistence.Table;

//import jakarta.validation.constraints.NotBlank;

@Entity

@Table(name = "Address")

public class Address {

	@Id

	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Long purchaseId;

	private String doorNumber;

	private String street;

	private String landmark;

	private String pincode;

	public Long getPurchaseId() {

		return purchaseId;

	}

	public void setPurchaseId(Long purchaseId) {

		this.purchaseId = purchaseId;

	}

	public String getDoorNumber() {

		return doorNumber;

	}

	public void setDoorNumber(String doorNumber) {

		this.doorNumber = doorNumber;

	}

	public String getStreet() {

		return street;

	}

	public void setStreet(String street) {

		this.street = street;

	}

	public String getLandmark() {

		return landmark;

	}

	public void setLandmark(String landmark) {

		this.landmark = landmark;

	}

	public String getPincode() {

		return pincode;

	}

	public void setPincode(String pincode) {

		this.pincode = pincode;

	}

}
