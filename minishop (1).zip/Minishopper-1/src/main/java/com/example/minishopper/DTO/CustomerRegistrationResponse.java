package com.example.minishopper.DTO;


public class CustomerRegistrationResponse {

	private String responseMessage;
	
	public void setResponseMessage(String responseMessage){
		this.responseMessage = responseMessage;
	}
	
	public String getResponseMessage(){
		return responseMessage;
	}
}
