package com.example.minishopper.utils;

import com.example.minishopper.model.Customer;

public class MiniShopperUtils {
	
	public static boolean validateCustomerRegistrationRequest(Customer customer) {
		boolean validationResult = false;
		return validationResult;
	}

}
