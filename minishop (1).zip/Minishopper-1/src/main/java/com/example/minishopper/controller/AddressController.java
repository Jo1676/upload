package com.example.minishopper.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
 
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
 
import org.springframework.web.bind.annotation.RestController;

import com.example.minishopper.DTO.AddressRequest;
import com.example.minishopper.Service.AddressService;

import jakarta.validation.Valid;
 
@RestController
@RequestMapping("/api/orders")
public class AddressController {
 
    @Autowired
    private AddressService addressService;
 
    @PostMapping("/add")
    public ResponseEntity<String> addAddress(@Valid @RequestBody AddressRequest request) {
        // Validate delivery address
        if (StringUtils.isAnyBlank(request.getDoorNumber(),request.getStreet(),request.getLandmark(),request.getPincode())) {
            return ResponseEntity.badRequest().body("All fileds in Delivery address is required.");
        }
 
        addressService.processAddress(request);
        return ResponseEntity.ok("Address submitted successfully.");
    
 
 
    
 
    
}
}
