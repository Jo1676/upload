package com.example.minishopper.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.minishopper.model.Items;

public interface ItemRepository extends JpaRepository<Items, Long> {
	
}
   
