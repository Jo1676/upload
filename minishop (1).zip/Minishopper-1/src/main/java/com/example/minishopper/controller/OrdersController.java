package com.example.minishopper.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.minishopper.Service.OrdersService;
import com.example.minishopper.model.Orders;

import java.util.List;
@RestController
@RequestMapping("/api/orders")
public class OrdersController {
   @Autowired
   private OrdersService ordersService;
   @PostMapping("/place")
   public ResponseEntity<Orders> placeOrder(@RequestBody Orders order) {
       return ResponseEntity.ok(ordersService.placeOrder(order));
   }
   @GetMapping("/customer/{customerId}")
   public ResponseEntity<List<Orders>> getUserOrders(@PathVariable Long customerId) {
       return ResponseEntity.ok(ordersService.getUserOrders(customerId));
   }
   @GetMapping("/all")
   public ResponseEntity<List<Orders>> getAllOrders() {
       return ResponseEntity.ok(ordersService.getAllOrders());
   }
   @PutMapping("/update")
   public ResponseEntity<Orders> updateOrder(@RequestBody Orders order) {
       return ResponseEntity.ok(ordersService.updateOrder(order));
   }
   @PutMapping("/fulfill/{orderId}")
   public ResponseEntity<Orders> fulfillOrder(@PathVariable Long orderId) {
       return ResponseEntity.ok(ordersService.fulfillOrder(orderId));
   }
   @PutMapping("/reject/{orderId}")
   public ResponseEntity<Orders> rejectOrder(@PathVariable Long orderId) {
       return ResponseEntity.ok(ordersService.rejectOrder(orderId));
   }
}