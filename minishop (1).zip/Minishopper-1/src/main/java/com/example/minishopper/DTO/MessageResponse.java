package com.example.minishopper.DTO;

import java.util.Map;
public class MessageResponse {
private int status;
private Map<String, Object> data;
public MessageResponse( int status, Map<String, Object> data) {
super();
this.status = status;
this.data = data;
}
public int getStatus() {
return status;
}
public void setStatus(int status) {
this.status = status;
}
public Map<String, Object> getData() {
return data;
}
public void setData(Map<String, Object> data) {
this.data = data;
}
@Override
public String toString() {
return "MessageResponse [status=" + status + ", data=" + data + "]";
}

}